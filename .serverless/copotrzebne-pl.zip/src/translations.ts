import { DictionaryEntry } from './types/types'

export const translations: { [value: string]: DictionaryEntry } = {
  pageDescription: {
    namePl: `Nie wiesz gdzie potrzebna jest żywność, komu koce a gdzie zawieźć
     środki higieniczne? Zobacz aktualne zbiórki dla Ukrainy w twoim 
     mieście!`,
    nameEn:
      'You have no idea where to donate food, who needs blankets and where to deliver hygienic supplies? Check the ongoing collections for ukrainian refugees in your city!',
    nameUa: `Не знаєш, де потрібні продукти, кому треба ковдри, куди завезти засоби особистої гігієни? Перевір діючі пункти збирання допомоги для України у твоєму місті!`
  },
  shareActiveCollections: {
    namePl: 'Udostępnij aktywne zbiórki',
    nameEn: 'Share all ongoing collections',
    nameUa: 'Поділитися активними пунктами'
  },
  shareThisOrganizationCollection: {
    namePl: 'Udostępnij zbiórkę tej organizacji',
    nameEn: 'Share this collection',
    nameUa: 'Поділитися пунктом'
  },
  aboutUsPageTitle: {
    namePl: 'Copotrzebne.pl - O nas',
    nameEn: 'Copotrzebne.pl - About us',
    nameUa: 'Copotrzebne.pl - Про нас'
  },
  aboutUs: {
    namePl: `Pomagamy pomagać - łączymy miejsca oferujące pomoc rzeczową, noclegi i
      wsparcie osobom uchodźczym z Ukrainy - z osobami, które chciałyby je w tej
      pomocy wspierać. Ułatwiamy lokalizację zbiórek i pomagamy koordynować
      zaspokajanie podstawowych potrzeb. Dzięki nam dowiesz się, co jest
      aktualnie najbardziej potrzebne w twojej lokalizacji oraz gdzie i kiedy
      można dane rzeczy dostarczyć. 
      Jako część Koalicji Otwarty Kraków działamy na terenie Krakowa, ale zapraszamy do współpracy także inne organizacje oraz lokalizacje!`,
    nameEn: `We are helping others help by connecting charity aid places and foundations,
      providing support to refugees from Ukraine - with people who would like to donate goods or items.
      We make it easier to locate the ongoing collections and coordinate demands for given supply.
      Thanks to us, you will know what is most needed in the aid center in your location and where and what you can donate to help.
      As a part of the Open Krakow Coalition, we are actively working in Krakow, but we also invite other organisations and locations to come and join us!`,
    nameUa: `Помагаємо допомагати! 
    З'єднуємо пункти збирання допомоги, де пропонують речі, проживання і підтримку біженцям з України, з особами, які хочуть  таку допомогу надати.
    Полегшуємо пошук пунктів збирання допомоги, координуємо в них попит на основні потреби.
    Завдяки нам дізнаєшся, що цієї миті найнеобхідніше в пунктах твого міста,а також куди і коли можна доставити речі.`
  },
  contactDetails: {
    namePl: `Chcesz dodać zbiórkę w twojej organizacji?
      Skontaktuj się z nami:`,
    nameEn: `Do you want to add collections in your organisation here?
      Get in touch with us:`,
    nameUa: 'Хочете додати новий пункт збору допомоги? Напиши до нас:'
  },
  chooseCurrentDemands: {
    namePl: 'Wybierz aktualne potrzeby',
    nameEn: 'Choose your current needs',
    nameUa: 'Виберіть потрібні речі'
  },
  logIn: {
    namePl: 'Zaloguj się',
    nameEn: 'Login',
    nameUa: 'Увійти'
  },
  email: {
    namePl: 'Email',
    nameEn: 'Email',
    nameUa: 'Email'
  },
  password: {
    namePl: 'Hasło',
    nameEn: 'Password',
    nameUa: 'Пароль'
  },
  name: {
    namePl: 'Nazwa',
    nameEn: 'Name',
    nameUa: 'Назва'
  },
  city: {
    namePl: 'Miasto',
    nameEn: 'City',
    nameUa: 'Місто'
  },
  street: {
    namePl: 'Ulica',
    nameEn: 'Street',
    nameUa: 'Вулиця'
  },
  buildingNumber: {
    namePl: 'Numer budynku',
    nameEn: 'Building no.',
    nameUa: 'Номер будинку'
  },
  apartmentNumber: {
    namePl: 'Numer lokalu',
    nameEn: 'Flat',
    nameUa: 'Номер квартири'
  },
  workingHours: {
    namePl: 'Godziny otwarcia',
    nameEn: 'Working hours',
    nameUa: 'Робочі години'
  },
  comment: {
    namePl: 'Komentarz',
    nameEn: 'Comment',
    nameUa: 'Коментар'
  },
  phone: {
    namePl: 'Numer telefonu',
    nameEn: 'Contact person',
    nameUa: 'Номер телефону'
  },
  latitude: {
    namePl: 'Szerokość geograficzna',
    nameEn: 'Latitude',
    nameUa: 'Широта'
  },
  longitude: {
    namePl: 'Długość geograficzna',
    nameEn: 'Longitude',
    nameUa: 'Довгота'
  },
  bankAccount: {
    namePl: 'Numer konta bankowego do wpłat darowizn',
    nameEn: 'Bank account number for donations',
    nameUa: 'Номер банківського рахунку для внесення пожертв'
  },
  homepageLink: {
    namePl: 'Link do strony domowej organizacji',
    nameEn: 'Link to the home page of the organization',
    nameUa: 'Посилання на домашню сторінку організації'
  },
  facebookLink: {
    namePl: 'Link do strony organizacji na Facebooku',
    nameEn: 'Link to the Facebook page of the organization',
    nameUa: 'Посилання на сторінку організації у Facebook'
  },
  signupLink: {
    namePl: 'Link do zapisów na wolontariat w tym miejscu',
    nameEn: 'Link to register for voluntary service at this location',
    nameUa: 'Посилання для реєстрації на волонтерську службу тут'
  },
  fundraisingLink: {
    namePl: 'Link do zbiórki pieniężnej',
    nameEn: 'Link to fundraising',
    nameUa: 'Посилання на збір коштів'
  },
  save: {
    namePl: 'Zapisz',
    nameEn: 'Save',
    nameUa: 'Зберегти'
  },
  cancel: {
    namePl: 'Anuluj',
    nameEn: 'Cancel',
    nameUa: 'Cancel'
  },
  pageNotFound: {
    namePl: 'Nie znaleziono strony',
    nameEn: 'Page not found',
    nameUa: 'Сторінка не знайдена'
  },
  addPlace: {
    namePl: 'Dodaj miejsce',
    nameEn: 'Add place',
    nameUa: 'Додати нове місце'
  },
  placeLastUpdate: {
    namePl: 'Aktualizacja',
    nameEn: 'Last update',
    nameUa: 'Оновлено'
  },
  noDemandsReported: {
    namePl: 'Aktualnie nie masz zgłoszonych żadnych potrzeb',
    nameEn: 'You have no ongoing collections',
    nameUa: 'Наразі ви не додали жодних потреб'
  },
  addDemands: {
    namePl: 'Dodaj potrzeby',
    nameEn: 'Add demands',
    nameUa: 'Додати потребні речі'
  },
  finishCollection: {
    namePl: 'Zakończ zbiórkę',
    nameEn: 'Finish current collection',
    nameUa: 'Завершити збирання речей'
  },
  removeDemands: {
    namePl: 'Usuń wszystkie potrzeby',
    nameEn: 'Remove all demands',
    nameUa: 'Remove all demands'
  },
  lastUpdate: {
    namePl: 'Ostatnia aktualizacja:',
    nameEn: 'Last modified at:',
    nameUa: 'Останнє оновлення:'
  },
  demandsList: {
    namePl: 'Lista potrzeb',
    nameEn: 'Demands list',
    nameUa: 'Список потрібних речей'
  },
  addToList: {
    namePl: 'Dodaj do listy',
    nameEn: 'Add to list',
    nameUa: 'Add to list'
  },
  saveChanges: {
    namePl: 'Zapisz zmiany',
    nameEn: 'Save changes',
    nameUa: 'Save changes'
  },
  loggedInAs: {
    namePl: 'Jesteś zalogowany jako',
    nameEn: 'Logged in as',
    nameUa: 'Залогований як'
  },
  menuLogout: {
    namePl: 'Wyloguj się',
    nameEn: 'Log out',
    nameUa: 'Вийти'
  },
  menuAboutUs: {
    namePl: 'O nas',
    nameEn: 'About us',
    nameUa: 'Про нас'
  },
  menuPanel: {
    namePl: 'Panel',
    nameEn: 'Panel',
    nameUa: 'Панель'
  },
  menuLogIn: {
    namePl: 'Zaloguj się',
    nameEn: 'Log in',
    nameUa: 'Увійти'
  },
  requestPlace: {
    namePl: 'Dodaj nowe miejsce',
    nameEn: 'Add new place',
    nameUa: 'додати нове місце'
  },
  userEmail: {
    namePl: 'Email użytkownika - do stworzenia konta',
    nameEn: 'User email - for creating an account',
    nameUa: 'Електронна адреса користувача - для створення облікового запису'
  },
  fulfillRequiredFields: {
    namePl: 'Należy wypełnić wszystkie wymagane pola oznaczone znakiem *',
    nameEn: 'All required fields marked with * must be completed',
    nameUa: 'Усі обов’язкові поля, позначені *, необхідно заповнити'
  },
  thanksForRequestingPlace: {
    namePl: 'Dziękujemy za zgłoszenie nowego miejsca zbiórek.',
    nameEn: 'Thank you for creating a new place.',
    nameUa: 'Дякуємо, що повідомили про новий пункт збору.'
  },
  credentialsWillBeSent: {
    namePl: 'Dane do logowania prześlemy po weryfikacji miejsca.',
    nameEn: 'We will send login credentials after the data verification.',
    nameUa: 'Ми надішлемо дані для входу після перевірки місця.'
  },
  requestPlaceFailed: {
    namePl: 'Wystąpił nieznany błąd podczas zgłaszania miejsca.',
    nameEn: 'An unknown error has occurred during the creation of the place.',
    nameUa: 'Під час повідомлення про місце сталася невідома помилка.'
  },
  addNewPlace: {
    namePl: 'Dodaj nowe miejsce',
    nameEn: 'Add new place',
    nameUa: 'додати нове місце'
  },
  addNewPlaceDescription: {
    namePl:
      'Prowadzisz zbiórkę? Chcesz zgłosić miejsce zbiórki? Wypełnij formularz i podaj adres email. Otrzymamy twoje zgłoszenie, sprawdzimy je i utworzymy konto dla Ciebie. Dane do logowania otrzymasz na podany adres email.',
    nameEn:
      'Are you running a charity collection? Do you want to report a new place? Fill out the form and enter your email address. We will receive your application, check it and create an account for you. You will receive the login details at the e-mail address provided.',
    nameUa:
      'Ви проводите збір коштів? Ви хочете повідомити про місце зустрічі? Заповніть форму та введіть свою електронну адресу. Ми отримаємо вашу заявку, перевіримо її та створимо для вас обліковий запис. Ви отримаєте дані для входу на вказану адресу електронної пошти.'
  },
  editPlaceData: {
    namePl: 'Edytuj dane organizacji',
    nameEn: 'Edit data',
    nameUa: 'Редагуй дані про організацію'
  },
  updatePlaceLastUpdatedDate: {
    namePl: 'Lista potrzeb jest nadal aktualna',
    nameEn: 'The demands list is up to date',
    nameUa: 'Список потреб залишається актуальним'
  },
  editDemands: {
    namePl: 'Edytuj listę potrzeb',
    nameEn: 'Edit current demands',
    nameUa: 'Редагуй список потребних речей'
  },
  noOngoingCollections: {
    namePl: 'Brak aktualnych zbiórek',
    nameEn: 'No ongoing collections',
    nameUa: 'Пункт допомоги не збирає речей'
  },
  cookiesBarDescription: {
    namePl:
      'Cześć! Zbieramy ciasteczka aby analizować ruch na stronie i usprawniać funkcjonowanie serwisu.',
    nameEn:
      'Hi! We collect cookies to analyze website traffic and improve the functioning of the website.',
    nameUa:
      'Привіт! Ми збираємо файли cookies, щоб аналізувати рух на вебсайті та покращувати роботу нашого сервісу'
  },
  showMore: {
    namePl: 'Pokaż więcej',
    nameEn: 'Show more',
    nameUa: 'Показати більше'
  },
  showLess: {
    namePl: 'Pokaż mniej',
    nameEn: 'Show less',
    nameUa: 'Показати меньше'
  },
  showOnMap: {
    namePl: 'Zobacz na mapie',
    nameEn: 'See on map',
    nameUa: 'Подивитися на карті'
  },
  stateActive: {
    namePl: 'Aktywne',
    nameEn: 'Active',
    nameUa: 'активний'
  },
  stateInactive: {
    namePl: 'Nieaktywne',
    nameEn: 'Inactive',
    nameUa: 'неактивний'
  },
  notAnEmail: {
    namePl: 'Adres email nie jest poprawny',
    nameEn: 'Email address is not valid',
    nameUa: 'Адреса електронної пошти недійсна'
  },
  searchPlaceByName: {
    namePl: 'Szukaj po potrzebnych produktach',
    nameEn: 'Search by the products needed',
    nameUa: 'Пошук за потрібними продуктами'
  },
  searchPlacePlaceholder: {
    namePl: 'Np koce, kanapki, żywność',
    nameEn: 'blankets, sandwiches, food',
    nameUa: 'ковдри, бутерброди, їжа'
  },
  inputProductName: {
    namePl: 'Wpisz nazwę produktu',
    nameEn: 'Enter a product name',
    nameUa: 'Введіть назву продукту'
  },
  removeAll: {
    namePl: 'Usuń wszystkie',
    nameEn: 'Remove all',
    nameUa: 'Видалити всі'
  },
  managePlaces: {
    namePl: 'Zarządzaj miejscami',
    nameEn: 'Manage places',
    nameUa: 'Керуйте місцями'
  },
  placeId: {
    namePl: 'ID miejsca',
    nameEn: 'Place ID',
    nameUa: 'Place ID'
  },
  createUser: {
    namePl: 'Dodaj użytkownika',
    nameEn: 'Create user',
    nameUa: 'Create user'
  },
  login: {
    namePl: 'Login',
    nameEn: 'Login',
    nameUa: 'Login'
  },
  urgentlyNeeded: {
    namePl: 'Pilnie potrzebne!',
    nameEn: 'Urgently needed',
    nameUa: 'Терміново потрібна'
  },
  notFound: {
    namePl: 'Nie znaleziono',
    nameEn: 'Not found',
    nameUa: 'Не знайдено'
  },
  additionalDescription: {
    namePl: 'Dodatkowy opis miejsca',
    nameEn: 'Additional description',
    nameUa: 'Additional description'
  },
  howCanIHelp: {
    namePl: 'Jak mogę pomóc?',
    nameEn: 'How can I help?',
    nameUa: 'Чим я можу допомогти?'
  },
  organizationLabel: {
    namePl: 'Organizacja',
    nameEn: 'Organization',
    nameUa: 'Організація'
  },
  faqAccountNumberDescription: {
    namePl:
      'Aktualny numer konta ogranizacji: <br /><b>{bankAccountNumber}</b>',
    nameEn:
      "Organization's current account number: <br /><b>{bankAccountNumber}</b>",
    nameUa:
      'Номер поточного рахунку організації: <br /><b>{bankAccountNumber}</b>'
  },
  faqFundraisingDescription: {
    namePl: 'Strona gdzie można nas wspomóc: {fundraising}',
    nameEn: 'Page where you can help us: {fundraising}',
    nameUa: 'Сторінка, де ви можете нам допомогти: {fundraising}'
  },
  faqTitle_1: {
    namePl: 'Chcę przekazać pieniądze, jak mogę to zrobić?',
    nameEn: 'I want to donate money, how can I do it?',
    nameUa: 'Я хочу пожертвувати гроші, як я можу це зробити?'
  },
  faqText_1: {
    namePl:
      'Weryfikujemy organizacje przed dodaniem ich do systemu. Numer konta ogranizacji: <br /><b>{bankAccountNumber}</b>',
    nameEn:
      'We verify organizations before adding them to the system. Organization Account Number: <br /><b>{bankAccountNumber}</b>',
    nameUa:
      'Ми перевіряємо організації, перш ніж додати їх до системи. Номер рахунку організації: <br /><b>{bankAccountNumber}</b>'
  },
  faqTitle_2: {
    namePl: 'Chcę przekazać żywność, jak mogę to zrobić?',
    nameEn: 'I want to donate goods, how can I do it?',
    nameUa: 'Я хочу пожертвувати товари, як я можу це зробити?'
  },
  faqText_2: {
    namePl:
      'Wszystkie dary można przywieść pod adres: <br /> <b>{address}</b> <br /> Godziny otwarcia: <b>{workingHours}</b>',
    nameEn:
      'All donations can be brought to: <br /> <b> {address} </b> <br /> Opening hours: <b> {workingHours} </b>',
    nameUa: ''
  },
  faqTitle_3: {
    namePl: 'Mieszkam dość daleko od tej organizacji, jak mogę pomóc?',
    nameEn: 'I live quite far away from this organisation, how can I help?',
    nameUa: 'Я живу досить далеко від цієї організації, як я можу допомогти?'
  },
  faqText_3: {
    namePl: '',
    nameEn: '',
    nameUa: ''
  },
  faqTitle_4: {
    namePl: 'Mieszkam za granicą, jak mogę pomóc?',
    nameEn: 'I live abroad, how can I help?',
    nameUa: 'Я живу за кордоном, як я можу допомогти?'
  },
  faqText_4: {
    namePl: `Nawet będąc daleko możesz pomóc na wiele sposobów!<br /><br />
      Część organizacji prowadzi zbiórki pieniężne, a dzięki wpłatom ma fundusze realizację bieżących potrzeb Osób które korzystają z ich pomocy.<br />
      Jeżeli chcesz, możesz wesprzeć tą organizację finansowo: <br />
      <b>{bankAccountNumber}</b>
      <br />
      {fundraising}
      <br /><br />
      Jeśli reprezentujesz firmę lub fundację, lub po prostu masz możliwość zorganizowana większej dostawy darów z zagranicy to świetnie! Prosimy Cię jedynie o kontakt z organizacją i uprzedzenie jej o wielkości i terminie dostawy <br /><b>{contact} {address} <br/> {workingHours}</b>
      <br /><br />
      Poza pomocą rzeczową i finansową, możesz także pomóc rozpowszechniając informację o potrzebach danej organizacji oraz możliwych sposobach jej wsparcia - być może dzięki Twojej sieci kontaktów dotrzemy do organizacji i firm, które będą w stanie wesprzeć organizację rzeczowo lub finansowo.<br />
      A może sam(a) zorganizujesz zbiórkę wsród znajomych?`,
    nameEn: `Even if you live far away, there are still quite a few ways of helping!<br /><br />
      Some organisations have fundraising sites or collect funds on dedicated bank accounts; those funds are later used to buy needed supplies and provide them to People in need.
      If you want you can support this organisation financially <br />
      <b>{bankAccountNumber}</b>
      <br />
      {fundraising}
      <br /><br />

      If you represent a charity organisation, foundation or a company, or you just simply can organise a bigger transport with supplies - that’s great! We only kindly ask you to inform the organisation about incoming delivery, specifying the date of arrival and size of the package. You can find the organisation contact info here: <br /><b>{contact} {address} <br/> {workingHours}</b>
      <br /><br />
      Apart from delivering supplies and financial support, you can also help by spreading the information about the organisation’s needs and possible ways to provide help - perhaps thanks to your social network we will be able to reach companies and foundations able to support this organisation even more?<br />
      Or maybe you can organise a fundraising or goods collection event among your friends? :)  
      `,
    nameUa: ''
  },
  faqTitle_5: {
    namePl: 'Nie mam dużo wolnego czasu, jak mogę pomóc?',
    nameEn: 'I don’t have much free time, how can I help?',
    nameUa: 'У мене мало вільного часу, чим я можу допомогти?'
  },
  faqText_5: {
    namePl: '',
    nameEn: '',
    nameUa: ''
  },
  faqTitle_6: {
    namePl: 'Nie mam aktualnie środów, jak mogę pomóc?',
    nameEn: 'I can’t afford to buy a lot of goods, how can I help?',
    nameUa:
      'Я не можу дозволити собі купувати багато товарів, як я можу допомогти?'
  },
  faqText_6: {
    namePl: '',
    nameEn: '',
    nameUa: ''
  },
  faqTitle_7: {
    namePl: 'Mam trochę wolnego czasu, jak mogę pomóc?',
    nameEn: 'I have some spare time, how can I help?',
    nameUa: 'У мене є вільний час, як я можу допомогти?'
  },
  faqText_7: {
    namePl:
      'Tutaj jest link do zapisu na wolontariat w naszych punktach: {link}',
    nameEn: 'Here is a link to signup for a volunteer work, link: {link}',
    nameUa: 'Ось посилання для реєстрації на волонтерську роботу, посилання:'
  },
  menuInternalAnnouncements: {
    namePl: 'Zobacz ogłoszenia',
    nameEn: 'Browse announcements',
    nameUa: 'Browse announcements'
  },
  internalAnnouncementsTitle: {
    namePl: 'Lista ogłoszeń',
    nameEn: 'Announcements list',
    nameUa: 'Announcements list'
  },
  internalAnnouncementsSubtitle: {
    namePl:
      'Przeglądaj i dodawaj ogłoszenia. Możesz dodawać ogłoszenia publiczne widoczne na stronie głównej, oraz wewnętrzne, które są widoczne tylko dla innych zalogowanych osób koordynujących zbiórki.',
    nameEn:
      'Browse and add announcements. You can add public announcements visible on the home page, and internal announcements that are visible only to other logged-in collection coordinators.',
    nameUa:
      'Browse and add announcements. You can add public announcements visible on the home page, and internal announcements that are visible only to other logged-in collection coordinators.'
  },
  internalAnnouncementsSubtitle2: {
    namePl:
      'Zamieszczaj ważne informacje dla ciebie i innych koordynatorów. Masz za dużo produktów w magazynie lub nie masz jak przewieźć produktów? Poinformuj innych i umówcie się na wzajemną pomoc. Potrzebujesz wolontariuszy? Umieść publiczne ogłoszenie.',
    nameEn:
      'Post important information for you and other coordinators. Do you have too many products in stock or you do not have how to transport the products? Inform others and arrange for mutual assistance. Do you need volunteers? Add a public announcement.',
    nameUa:
      'Post important information for you and other coordinators. Do you have too many products in stock or you do not have how to transport the products? Inform others and arrange for mutual assistance. Do you need volunteers? Add a public announcement.'
  },
  announcementTitle: {
    namePl: 'Tytuł ogłoszenia',
    nameEn: 'Announcement title',
    nameUa: 'Announcement title'
  },
  announcementMessage: {
    namePl: 'Treść',
    nameEn: 'Message',
    nameUa: 'Message'
  },
  announcementStartDate: {
    namePl: 'Data rozpoczęcia',
    nameEn: 'Start date',
    nameUa: 'Start date'
  },
  announcementEndDate: {
    namePl: 'Data zakończenia',
    nameEn: 'End date',
    nameUa: 'End date'
  },
  failedToCreateAnnouncement: {
    namePl: 'Nie udało się zapisać ogłoszenia',
    nameEn: 'Failed to save the announcement',
    nameUa: 'Failed to save the announcement'
  },
  announcementContact: {
    namePl: 'Informacje kontaktowe',
    nameEn: 'Contact info',
    nameUa: 'Contact info'
  },
  announcementPlace: {
    namePl: 'Miejsce',
    nameEn: 'Place',
    nameUa: 'Place'
  },
  addComment: {
    namePl: 'Skomentuj',
    nameEn: 'Add comment',
    nameUa: 'Add comment'
  },
  hideComments: {
    namePl: 'Ukryj komentarze',
    nameEn: 'Hide comments',
    nameUa: 'Hide comments'
  },
  showComments: {
    namePl: 'Pokaż komentarze',
    nameEn: 'Show comments',
    nameUa: 'Show comments'
  },
  author: {
    namePl: 'Autor',
    nameEn: 'Author',
    nameUa: 'Author'
  },
  addedAt: {
    namePl: 'Dodano:',
    nameEn: 'Added:',
    nameUa: 'Added:'
  },
  validUntil: {
    namePl: 'Ważne do:',
    nameEn: 'Valid until:',
    nameUa: 'Valid until:'
  },
  contactInformation: {
    namePl: 'Dane kontaktowe:',
    nameEn: 'Contact:',
    nameUa: 'Contact:'
  },
  addInternalAnnouncement: {
    namePl: 'Dodaj ogłoszenie wewnętrzne',
    nameEn: 'Add internal announcement',
    nameUa: 'Add internal announcement'
  },
  addPublicAnnouncement: {
    namePl: 'Dodaj ogłoszenie publiczne',
    nameEn: 'Add public announcement',
    nameUa: 'Add public announcement'
  },
  publicAnnouncements: {
    namePl: 'Ogłoszenia publiczne',
    nameEn: 'Public announcements',
    nameUa: 'Public announcements'
  },
  internalAnnouncements: {
    namePl: 'Ogłoszenia wewnętrzne',
    nameEn: 'Internal announcements',
    nameUa: 'Internal announcements'
  },
  addAnnouncement: {
    namePl: 'Dodaj ogłoszenie',
    nameEn: 'Add announcement',
    nameUa: 'Add announcement'
  },
  whatisneededPl: {
    namePl: 'copotrzebne.pl',
    nameEn: 'whatisneeded.pl',
    nameUa: 'shchopotribno.pl'
  }
}
