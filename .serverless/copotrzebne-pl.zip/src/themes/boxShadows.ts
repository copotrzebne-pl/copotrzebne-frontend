export default {
  small: '0px 4px 4px rgba(0, 0, 0, 0.2)',
  medium: '1px -5px 14px 4px rgba(0, 0, 0, 0.1)'
}
